package com.example.prisonconnect.webrtc

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.app.PendingIntent
import android.telephony.SmsManager
import android.os.Build
import android.util.Log

class SmsController(private val context: Context) {

    private var smsSentReceiver: BroadcastReceiver? = null
    private var smsDeliveredReceiver: BroadcastReceiver? = null

    fun sendSmsWithDeliveryTracking(phone: String, message: String, type: String) {
        // Clean phone number - remove spaces, dashes, and add country code if needed
        val cleanPhone = phone.replace("[^0-9]".toRegex(), "")
        
        if (cleanPhone.isBlank() || cleanPhone.length < 10) {
            Log.e("SmsController", "Invalid phone number: $phone (cleaned: $cleanPhone)")
            throw IllegalArgumentException("Invalid phone number: $phone")
        }

        val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }

        val sentIntent = PendingIntent.getBroadcast(
            context, 0,
            Intent("SMS_SENT").putExtra("type", type),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val deliveryIntent = PendingIntent.getBroadcast(
            context, 0,
            Intent("SMS_DELIVERED").putExtra("type", type),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        unregisterReceivers()

        smsSentReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                val resultCode = getResultCode()
                val resultStr = when (resultCode) {
                    SmsManager.RESULT_ERROR_NONE -> "SUCCESS"
                    SmsManager.RESULT_ERROR_GENERIC_FAILURE -> "GENERIC_FAILURE"
                    SmsManager.RESULT_ERROR_RADIO_OFF -> "RADIO_OFF"
                    SmsManager.RESULT_ERROR_NULL_PDU -> "NULL_PDU"
                    SmsManager.RESULT_ERROR_NO_SERVICE -> "NO_SERVICE"
                    SmsManager.RESULT_ERROR_LIMIT_EXCEEDED -> "LIMIT_EXCEEDED"
                    else -> "UNKNOWN_ERROR($resultCode)"
                }
                Log.d("SmsController", "$type SMS sent callback received, resultCode=$resultStr")
            }
        }

        smsDeliveredReceiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                val resultCode = getResultCode()
                val resultStr = when (resultCode) {
                    SmsManager.RESULT_ERROR_NONE -> "DELIVERED"
                    SmsManager.RESULT_ERROR_GENERIC_FAILURE -> "GENERIC_FAILURE"
                    SmsManager.RESULT_ERROR_RADIO_OFF -> "RADIO_OFF"
                    SmsManager.RESULT_ERROR_NULL_PDU -> "NULL_PDU"
                    SmsManager.RESULT_ERROR_NO_SERVICE -> "NO_SERVICE"
                    else -> "UNKNOWN($resultCode)"
                }
                Log.d("SmsController", "$type SMS delivery callback received, resultCode=$resultStr")
            }
        }

        context.registerReceiver(smsSentReceiver, IntentFilter("SMS_SENT"))
        context.registerReceiver(smsDeliveredReceiver, IntentFilter("SMS_DELIVERED"))

        try {
            val messageParts = smsManager.divideMessage(message)
            val sentIntents = ArrayList<PendingIntent>()
            val deliveryIntents = ArrayList<PendingIntent>()

            repeat(messageParts.size) {
                sentIntents.add(sentIntent)
                deliveryIntents.add(deliveryIntent)
            }

            smsManager.sendMultipartTextMessage(cleanPhone, null, messageParts, sentIntents, deliveryIntents)
            Log.d("SmsController", "$type SMS queued successfully to $cleanPhone (original: $phone)")
        } catch (ex: Exception) {
            Log.e("SmsController", "$type SMS send failed", ex)
            throw ex
        }
    }

    fun unregisterReceivers() {
        try {
            smsSentReceiver?.let { context.unregisterReceiver(it) }
            smsDeliveredReceiver?.let { context.unregisterReceiver(it) }
            smsSentReceiver = null
            smsDeliveredReceiver = null
        } catch (e: Exception) {
            Log.w("SmsController", "Receivers already unregistered or not found", e)
        }
    }
}