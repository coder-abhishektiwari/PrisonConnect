package com.example.prisonconnect

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import android.view.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.prisonconnect.databinding.FragmentCallRoomBinding
import com.example.prisonconnect.model.CallRoom
import com.example.prisonconnect.repository.DbService
import com.example.prisonconnect.webrtc.SignalingClient
import com.example.prisonconnect.webrtc.SmsController
import com.example.prisonconnect.webrtc.WebRtcManager
import kotlinx.coroutines.*
import kotlinx.serialization.json.*
import org.webrtc.*
import java.util.*

class CallRoomFragment : Fragment(), WebRtcManager.WebRtcListener, SignalingClient.SignalingListener {

    private var _binding: FragmentCallRoomBinding? = null
    private val binding get() = _binding!!

    private var roomId: String? = null
    private var contactPhone: String = ""
    private var kioskId: String = "KIOSK_001"
    private var sessionId: String = UUID.randomUUID().toString()
    private var roomOtp: String = ""
    private var roomToken: String = ""
    private var inmateId: String = ""
    private var inmateName: String = ""

    private lateinit var smsController: SmsController
    private lateinit var webRtcManager: WebRtcManager
    private var signalingClient: SignalingClient? = null

    private var recordingService: SecureHardwareRecordingService? = null
    private var isServiceBound = false
    private var roomPollJob: Job? = null
    private var smsJob: Job? = null
    private var isCallStarted = false
    private var isOtpSent = false
    private var currentRoomState = RoomState.UNKNOWN
    private var hasSmsPermission = false
    private var hasCameraAudioPermission = false
    private var isRemoteDescriptionSet = false
    private val pendingCandidates = mutableListOf<IceCandidate>()
    private var candidateBatchJob: Job? = null
    private var remoteVideoTrack: VideoTrack? = null

    private val eglBase = EglBase.create()

    private enum class RoomState {
        WAITING, OTP_SENT, ACTIVE, CONNECTED, DISCONNECTED, TAMPER_KILLED, UNKNOWN
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as SecureHardwareRecordingService.LocalBinder
            recordingService = binder.getService()
            isServiceBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            isServiceBound = false
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasCameraAudioPermission = permissions[Manifest.permission.CAMERA] == true &&
                permissions[Manifest.permission.RECORD_AUDIO] == true
        hasSmsPermission = permissions[Manifest.permission.SEND_SMS] == true

        if (hasSmsPermission && currentRoomState == RoomState.WAITING && smsJob?.isActive != true) {
            lifecycleScope.launch {
                val receiverPhone = roomId?.let { 
                    val room = DbService.getDocumentByColumn<CallRoom>("call_rooms", "room_id", it)
                    room?.receiver_phone ?: room?.receiverPhone
                }
                if (!receiverPhone.isNullOrBlank()) startSmsLoop(receiverPhone)
            }
        }

        if (currentRoomState == RoomState.ACTIVE && !isCallStarted && hasCameraAudioPermission) {
            activateCallSession()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentCallRoomBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        val binding = _binding ?: return
        
        smsController = SmsController(requireContext())
        webRtcManager = WebRtcManager(requireContext(), eglBase, this)
        webRtcManager.initialize()

        val callType = arguments?.getString("call_type") ?: "VIDEO"
        inmateId = arguments?.getString("user_id") ?: "INMATE_001"
        inmateName = arguments?.getString("inmate_name") ?: arguments?.getString("full_name") ?: "Inmate"
        roomId = arguments?.getString("room_id") ?: "ROOM_${System.currentTimeMillis()}"
        contactPhone = arguments?.getString("phone_number") ?: ""

        Log.d("CallRoom abhishek", "onViewCreated - roomId: $roomId, contactPhone: $contactPhone, inmateName: $inmateName")

        initializeLobbyUi(binding)

        viewLifecycleOwner.lifecycleScope.launch {
            initializeRoom(inmateId, callType)
            
            // Wait for room to be created and verify
            var room: CallRoom? = null
            for (i in 1..5) {
                delay(1000)
                room = DbService.getDocumentByColumn<CallRoom>("call_rooms", "room_id", roomId.toString())
                if (room != null) {
                    Log.d("CallRoom abhishek", "Room found after $i seconds - receiver_phone: ${room.receiver_phone}, receiverPhone: ${room.receiverPhone}")
                    break
                }
            }
            
            if (_binding == null) return@launch
            if (room == null) {
                showLobby(binding, "❌ Error: Room not created. Please try again.")
                return@launch
            }
            requestInitialPermissions()
            // If permissions are already granted, start SMS loop immediately
            if (hasSmsPermission) {
                val receiverPhone = room.receiver_phone ?: room.receiverPhone
                if (!receiverPhone.isNullOrBlank()) {
                    startSmsLoop(receiverPhone)
                }
            }
            observeRoomStatus()
        }
    }

    private fun checkAndStartSms() {
        if (hasSmsPermission && currentRoomState == RoomState.WAITING && smsJob?.isActive != true) {
            viewLifecycleOwner.lifecycleScope.launch {
                val room = roomId?.let { 
                    DbService.getDocumentByColumn<CallRoom>("call_rooms", "room_id", it)
                }
                val receiverPhone = room?.receiver_phone ?: room?.receiverPhone
                if (!receiverPhone.isNullOrBlank()) {
                    startSmsLoop(receiverPhone)
                }
            }
        }
    }

    private fun initializeLobbyUi(binding: FragmentCallRoomBinding) {
        binding.lobbyContainer.visibility = View.VISIBLE
        binding.videoContainer.visibility = View.GONE
        binding.lobbyProgress.visibility = View.VISIBLE
        binding.tvLobbyStatus.text = "Waiting for terminal response..."
        binding.btnCancelCall.setOnClickListener {
            updateRoomStatus("DISCONNECTED")
            teardownAndExit()
        }
    }

    private suspend fun initializeRoom(inmateId: String, callType: String) {
        val id = roomId ?: return
        try {
            roomOtp = (100000..999999).random().toString()
            roomToken = "sess_${UUID.randomUUID().toString().replace("-", "")}"

            val existing: CallRoom? = DbService.getDocumentByColumn("call_rooms", "room_id", id)
            if (existing != null) {
                DbService.updateFieldsByColumn("call_rooms", "room_id", id, mapOf(
                    "kiosk_id" to kioskId,
                    "inmate_id" to inmateId,
                    "call_type" to callType,
                    "room_status" to "WAITING",
                    "otp" to roomOtp,
                    "token" to roomToken
                ))
            } else {
                val roomData: Map<String, Any> = mapOf(
                    "room_id" to id,
                    "kiosk_id" to kioskId,
                    "inmate_id" to inmateId,
                    "call_type" to callType,
                    "room_status" to "WAITING",
                    "receiver_phone" to contactPhone,
                    "otp" to roomOtp,
                    "token" to roomToken,
                    "webrtc_signaling" to mapOf("offer" to null, "answer" to null, "iceCandidates" to emptyList<Map<String, Any>>())
                )
                DbService.insertRaw("call_rooms", roomData)
            }
        } catch (ex: Exception) {
            Log.e("CallRoom abhishek", "initializeRoom failed", ex)
        }
    }

    private fun requestInitialPermissions() {
        val requiredPermissions = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.SEND_SMS)
        val missing = requiredPermissions.filter { ContextCompat.checkSelfPermission(requireContext(), it) != PackageManager.PERMISSION_GRANTED }

        if (missing.isNotEmpty()) {
            permissionLauncher.launch(requiredPermissions.toTypedArray())
        } else {
            hasCameraAudioPermission = true
            hasSmsPermission = true
        }
    }

    private fun observeRoomStatus() {
        roomId?.let { id ->
            roomPollJob = viewLifecycleOwner.lifecycleScope.launch {
                delay(500L)
                while (isActive) {
                    try {
                        val room: CallRoom? = DbService.getDocumentByColumn("call_rooms", "room_id", id)
                        val stateValue = room?.room_status?.uppercase() ?: "UNKNOWN"
                        val receiverPhone = room?.receiver_phone ?: room?.receiverPhone

                        val binding = _binding
                        if (binding == null) {
                            Log.w("CallRoom abhishek", "Binding is null, skipping UI update")
                            delay(3000L)
                            continue
                        }

                        when (stateValue) {
                            "WAITING" -> {
                                currentRoomState = RoomState.WAITING
                                showLobby(binding, "📱 Call link sent! Waiting for receiver to open...")
                                stopRecordingService()
                                if (!receiverPhone.isNullOrBlank() && hasSmsPermission && smsJob?.isActive != true) {
                                    startSmsLoop(receiverPhone)
                                }
                            }
                            "OTP_SENT" -> {
                                currentRoomState = RoomState.OTP_SENT
                                showLobby(binding, "✅ Link opened! Sending access code...")
                                if (!receiverPhone.isNullOrBlank() && hasSmsPermission) {
                                    sendOtpSms(receiverPhone)
                                }
                                stopSmsLoop()
                            }
                            "ACTIVE" -> {
                                currentRoomState = RoomState.ACTIVE
                                showLobby(binding, "🔐 Access code verified! Connecting to call...")
                                stopSmsLoop()
                                if (!isCallStarted && hasCameraAudioPermission) activateCallSession()
                            }
                            "CONNECTED" -> {
                                currentRoomState = RoomState.CONNECTED
                                showLobby(binding, "✅ Call connected!")
                            }
                            "DISCONNECTED", "TAMPER_KILLED" -> teardownAndExit()
                            else -> showLobby(binding, "Waiting for terminal response...")
                        }
                    } catch (e: Exception) {
                        Log.e("CallRoom abhishek", "Room polling failed", e)
                    }
                    delay(3000L)
                }
            }
        }
    }

    private var isLinkSent = false
    
    private fun startSmsLoop(phone: String) {
        Log.d("CallRoom abhishek", "startSmsLoop called with phone: $phone, isLinkSent: $isLinkSent, hasSmsPermission: $hasSmsPermission, contactPhone: $contactPhone")
        smsJob = viewLifecycleOwner.lifecycleScope.launch {
            try {
                // Use contactPhone as fallback if phone is empty
                val targetPhone = if (phone.isNotBlank()) phone else contactPhone
                if (!isLinkSent && targetPhone.isNotBlank()) {
                    isLinkSent = true
                    val smsLink = "https://prisonconnect-call.rf.gd/index.html?room=$roomId&token=$roomToken"
                    val linkMessage = "PrisonConnect: You have a video call request from Inmate: $inmateName at $kioskId. Join: $smsLink"
                    Log.d("CallRoom abhishek", "Sending SMS link to: $targetPhone")
                    smsController.sendSmsWithDeliveryTracking(targetPhone, linkMessage, "LINK")
                    val binding = _binding ?: return@launch
                    showLobby(binding, "📱 Call link sent! Waiting for receiver to open...")
                } else {
                    Log.w("CallRoom abhishek", "SMS not sent - isLinkSent: $isLinkSent, phone blank: ${targetPhone.isBlank()}")
                    val binding = _binding ?: return@launch
                    showLobby(binding, "❌ SMS not sent. Phone number may be invalid or SMS quota exceeded.")
                }
            } catch (ex: Exception) {
                Log.e("CallRoom abhishek", "SMS send failed", ex)
                val binding = _binding ?: return@launch
                showLobby(binding, "❌ SMS send failed: ${ex.message}. Please check SMS quota.")
            }
            while (isActive && currentRoomState == RoomState.WAITING) delay(1000)
        }
    }

    private fun sendOtpSms(phone: String) {
        if (roomOtp.isBlank() || !hasSmsPermission || isOtpSent) return
        isOtpSent = true
        try {
            val otpMessage = "PrisonConnect: Your access code is: $roomOtp. Enter this code on the website to join the call."
            smsController.sendSmsWithDeliveryTracking(phone, otpMessage, "OTP")
            val binding = _binding ?: return
            showLobby(binding, "✅ Access code sent! Please check your messages.")
        } catch (ex: Exception) {
            isOtpSent = false // Reset on failure
            val binding = _binding ?: return
            showLobby(binding, "❌ Failed to send access code. Please try again.")
        }
    }

    private fun activateCallSession() {
        if (isCallStarted) return
        isCallStarted = true
        stopSmsLoop()

        val binding = _binding ?: return
        
        binding.localView.init(eglBase.eglBaseContext, null)
        binding.localView.setMirror(true)
        binding.remoteView.init(eglBase.eglBaseContext, null)

        webRtcManager.setupPeerConnection()
        webRtcManager.startLocalStream(binding.localView)

        signalingClient = SignalingClient(roomId!!, viewLifecycleOwner.lifecycleScope, this)
        signalingClient?.connect()

        startRecordingService()
        showCallUi(binding)
    }

    override fun onRemoteVideoTrackReceived(videoTrack: VideoTrack) {
        Log.d("CallRoom abhishek", "Remote video track received: ${videoTrack.id()}")
        remoteVideoTrack = videoTrack
        val binding = _binding ?: return
        videoTrack.addSink(binding.remoteView)
    }

    override fun onIceCandidateGenerated(candidate: IceCandidate) {
        pendingCandidates.add(candidate)
        if (candidateBatchJob?.isActive != true) {
            candidateBatchJob = lifecycleScope.launch {
                delay(100)
                if (pendingCandidates.isNotEmpty()) {
                    val candidatesToSend = pendingCandidates.toList()
                    pendingCandidates.clear()
                    val jsonArray = JsonArray(candidatesToSend.map {
                        buildJsonObject {
                            put("sdpMid", it.sdpMid ?: "")
                            put("sdpMLineIndex", it.sdpMLineIndex)
                            put("sdp", it.sdp)
                        }
                    })
                    signalingClient?.sendCandidateBatch(jsonArray)
                }
            }
        }
    }

    override fun onIceConnected() { updateRoomStatus("CONNECTED") }

    override fun onSiteOpened() { 
        val binding = _binding ?: return
        if (currentRoomState == RoomState.WAITING) showLobby(binding, "✅ Link opened! Waiting for OTP verification...") 
    }
    override fun onOtpVerified() { 
        val binding = _binding ?: return
        if (currentRoomState == RoomState.OTP_SENT) showLobby(binding, "🔐 Access code verified! Connecting to call...") 
    }
    
    override fun onAnswerReceived(sdp: String, type: String) {
        val sessionDescription = SessionDescription(SessionDescription.Type.fromCanonicalForm(type), sdp)
        webRtcManager.peerConnection?.setRemoteDescription(object : SdpObserver {
            override fun onSetSuccess() {
                isRemoteDescriptionSet = true
                Log.d("CallRoom abhishek", "Remote description set successfully")
                if (pendingCandidates.isNotEmpty()) {
                    pendingCandidates.forEach { webRtcManager.peerConnection?.addIceCandidate(it) }
                    pendingCandidates.clear()
                }
            }
            override fun onCreateSuccess(p0: SessionDescription?) {}
            override fun onCreateFailure(p0: String?) {}
            override fun onSetFailure(p0: String?) {
                Log.e("CallRoom abhishek", "Failed to set remote description: $p0")
            }
        }, sessionDescription)
    }

    override fun onCandidateBatchReceived(candidates: List<JsonObject>) {
        candidates.forEach { candidateData ->
            val sdpMid = candidateData["sdpMid"]?.jsonPrimitive?.content
            val sdpMLineIndex = candidateData["sdpMLineIndex"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0
            val sdp = candidateData["sdp"]?.jsonPrimitive?.content
            if (sdp != null) {
                val candidate = IceCandidate(sdpMid, sdpMLineIndex, sdp)
                if (isRemoteDescriptionSet) {
                    webRtcManager.peerConnection?.addIceCandidate(candidate)
                } else {
                    pendingCandidates.add(candidate)
                }
            }
        }
    }

    override fun onWebReady() {
        val binding = _binding ?: return
        val pc = webRtcManager.peerConnection
        if (pc?.remoteDescription == null && pc?.signalingState() == PeerConnection.SignalingState.STABLE) {
            pc?.createOffer(object : SdpObserver {
                override fun onCreateSuccess(sdp: SessionDescription) {
                    pc.setLocalDescription(object : SdpObserver {
                        override fun onSetSuccess() { signalingClient?.sendOffer(sdp.description, sdp.type.canonicalForm()) }
                        override fun onCreateSuccess(p0: SessionDescription?) {}
                        override fun onCreateFailure(p0: String?) {}
                        override fun onSetFailure(p0: String?) {}
                    }, sdp)
                }
                override fun onSetSuccess() {}
                override fun onCreateFailure(p0: String?) {}
                override fun onSetFailure(p0: String?) {}
            }, MediaConstraints())
        }
    }

    override fun onHangupReceived() { teardownAndExit() }

    private fun showLobby(binding: FragmentCallRoomBinding, message: String) {
        binding.lobbyContainer.visibility = View.VISIBLE
        binding.videoContainer.visibility = View.GONE
        binding.tvLobbyStatus.text = message
    }

    private fun showCallUi(binding: FragmentCallRoomBinding) {
        binding.lobbyContainer.visibility = View.GONE
        binding.videoContainer.visibility = View.VISIBLE
        binding.btnDisconnect.setOnClickListener {
            updateRoomStatus("DISCONNECTED")
            teardownAndExit()
        }
    }

    private fun updateRoomStatus(status: String) {
        roomId?.let { id ->
            lifecycleScope.launch {
                try { DbService.updateFieldsByColumn("call_rooms", "room_id", id, mapOf("room_status" to status)) }
                catch (ex: Exception) { Log.e("CallRoom abhishek", "updateRoomStatus failed", ex) }
            }
        }
    }

    private fun startRecordingService() {
        val intent = Intent(requireContext(), SecureHardwareRecordingService::class.java).apply {
            putExtra("ROOM_ID", roomId)
            putExtra("KIOSK_ID", kioskId)
            putExtra("SESSION_ID", sessionId)
        }
        requireContext().startForegroundService(intent)
        requireContext().bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
    }

    private fun stopRecordingService() {
        if (isServiceBound) {
            recordingService?.stopAndUpload()
            requireContext().unbindService(serviceConnection)
            isServiceBound = false
        }
    }

    private fun stopSmsLoop() {
        smsJob?.cancel()
        smsJob = null
    }

    private fun teardownAndExit() {
        stopSmsLoop()
        stopRecordingService()
        smsController.unregisterReceivers()
        webRtcManager.cleanup()
        signalingClient?.sendHangupAndDisconnect()
        roomPollJob?.cancel()
        deleteRoom()
        // Go back to dashboard instead of login
        (requireActivity() as? KioskMainActivity)?.navigateToFragment(DashboardFragment().apply {
            arguments = Bundle().apply { putString("user_id", inmateId) }
        }, false)
    }

    private fun deleteRoom() {
        roomId?.let { id ->
            lifecycleScope.launch {
                try {
                    DbService.deleteByColumn("call_rooms", "room_id", id)
                    Log.d("CallRoom abhishek", "Room deleted: $id")
                } catch (ex: Exception) {
                    Log.e("CallRoom abhishek", "Failed to delete room", ex)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        // Just clean up resources, don't navigate
        stopSmsLoop()
        stopRecordingService()
        smsController.unregisterReceivers()
        webRtcManager.cleanup()
        signalingClient?.sendHangupAndDisconnect()
        roomPollJob?.cancel()
        eglBase.release()
        _binding = null
    }
}