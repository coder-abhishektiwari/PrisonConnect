package com.example.prisonconnect.webrtc

import android.content.Context
import android.util.Log
import org.webrtc.*

class WebRtcManager(
    private val context: Context,
    private val eglBase: EglBase,
    private val listener: WebRtcListener
) {
    interface WebRtcListener {
        fun onIceCandidateGenerated(candidate: IceCandidate)
        fun onIceConnected()
        fun onRemoteVideoTrackReceived(videoTrack: VideoTrack)
    }

    private var factory: PeerConnectionFactory? = null
    var peerConnection: PeerConnection? = null
        private set
    private var localVideoTrack: VideoTrack? = null
    private var localAudioTrack: AudioTrack? = null
    private var videoCapturer: VideoCapturer? = null

    fun initialize() {
        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .setEnableInternalTracer(true)
                .createInitializationOptions()
        )

        val options = PeerConnectionFactory.Options()
        val encoderFactory = DefaultVideoEncoderFactory(eglBase.eglBaseContext, true, true)
        val decoderFactory = DefaultVideoDecoderFactory(eglBase.eglBaseContext)

        factory = PeerConnectionFactory.builder()
            .setOptions(options)
            .setVideoEncoderFactory(encoderFactory)
            .setVideoDecoderFactory(decoderFactory)
            .createPeerConnectionFactory()
    }

    fun setupPeerConnection() {
        val iceServers = listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
        )

        val rtcConfig = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }

        peerConnection = factory?.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate) {
                listener.onIceCandidateGenerated(candidate)
            }

            override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {
                // Handle remote tracks
                streams.forEach { stream ->
                    stream.videoTracks.forEach { track ->
                        Log.d("WebRtcManager", "Remote video track added: ${track.id()}")
                        listener.onRemoteVideoTrackReceived(track)
                    }
                }
            }

            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState) {
                if (newState == PeerConnection.IceConnectionState.CONNECTED) {
                    listener.onIceConnected()
                }
            }

            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddStream(p0: MediaStream?) {}
        })
    }

    fun startLocalStream(localSink: VideoSink) {
        val audioSource = factory?.createAudioSource(MediaConstraints())
        localAudioTrack = factory?.createAudioTrack("ARDAMSa0", audioSource).apply { this?.setEnabled(true) }

        videoCapturer = createVideoCapturer()
        val videoSource = factory?.createVideoSource(false)

        videoCapturer?.initialize(
            SurfaceTextureHelper.create("VideoCapturerThread", eglBase.eglBaseContext),
            context,
            videoSource?.capturerObserver
        )
        videoCapturer?.startCapture(1280, 720, 30)

        localVideoTrack = factory?.createVideoTrack("ARDAMSv0", videoSource).apply {
            this?.setEnabled(true)
            this?.addSink(localSink)
        }

        peerConnection?.addTrack(localAudioTrack)
        peerConnection?.addTrack(localVideoTrack)
    }

    private fun createVideoCapturer(): VideoCapturer? {
        val enumerator = Camera2Enumerator(context)
        return enumerator.deviceNames.firstOrNull { enumerator.isFrontFacing(it) }
            ?.let { enumerator.createCapturer(it, null) }
    }

    fun cleanup() {
        try { videoCapturer?.stopCapture() } catch (e: Exception) {}
        try { localVideoTrack?.dispose() } catch (e: Exception) {}
        try { localAudioTrack?.dispose() } catch (e: Exception) {}
        try { peerConnection?.close() } catch (e: Exception) {}
        try { factory?.dispose() } catch (e: Exception) {}
        try { videoCapturer?.dispose() } catch (e: Exception) {}
        
        peerConnection = null
        factory = null
        localVideoTrack = null
        localAudioTrack = null
        videoCapturer = null
    }
}